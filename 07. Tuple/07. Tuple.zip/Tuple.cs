﻿namespace _07._Tuple
{
    public class MyTuple<T1, T2>
    {
        public MyTuple(T1 firstItem, T2 secondItem)
        {
            this.firstItem = firstItem;
            this.secondItem = secondItem;
        }

        public T1 firstItem { get; set; } 

        public T2 secondItem { get; set; }

        public void PrintOutput()
        {
            Console.WriteLine($"{this.firstItem} -> {this.secondItem}");
        }
    }
}
