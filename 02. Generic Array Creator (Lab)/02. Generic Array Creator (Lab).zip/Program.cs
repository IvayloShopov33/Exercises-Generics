﻿namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] names = ArrayCreator.Create(5, "John");
            int[] numbers = ArrayCreator.Create(8, 15);
            Console.WriteLine(string.Join(", ", names));
            Console.WriteLine(string.Join(", ", numbers));
        }
    }
}